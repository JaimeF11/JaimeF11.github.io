<!DOCTYPE html><html>
<head>
    <title>WAH WAH WAH - UACloud Campus Virtual</title>
    <meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/><link rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/font-awesome.min.css"/><link type="text/css" rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/bootstrap.3.3.5.min.css"/><link rel="stylesheet" href="/cas/css/custom.css"/><link rel="icon" href="https://cvnet.cpd.ua.es/guiaestilo/cas/favicon.ico" type="image/x-icon"/><script type="text/javascript" src="https://cvnet.cpd.ua.es/guiaestilo/js/zxcvbn-4.3.0.js"></script>
    <script type="text/javascript" src="https://cvnet.cpd.ua.es/guiaestilo/js/jquery.min-1.11.3.js"></script>
    <script type="text/javascript" src="https://cvnet.cpd.ua.es/guiaestilo/js/jquery-ui.min-1.11.4.js"></script>
    <script type="text/javascript" src="https://cvnet.cpd.ua.es/guiaestilo/js/jquery.cookie.min-1.4.1.js"></script>
    <script src="https://cvnet.cpd.ua.es/guiaestilo/js/bootstrap.3.3.5.min.js"></script>


    <link href='https://cvnet.cpd.ua.es/guiaestilo/css/cas/lato.css' rel='stylesheet' type='text/css' /><link type="text/css" rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/cas/cas2-cleaned.css"><link type="text/css" rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/cas/skin.css"><link type="text/css" rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/cas/layout.css"><link type="text/css" rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/cas/layout-responsive.css"><link rel="stylesheet" href="https://cvnet.cpd.ua.es/guiaestilo/css/styles-iconsua.css"><style>
        @import 'https://fonts.googleapis.com/css?family=Gloria+Hallelujah';

        .prompt {
            font-family: 'Gloria Hallelujah', cursive;
        }
    </style>
</head>

<body id="cas">
    <div id="content">
    <div class="alert alert-info">
        <h2 class="prompt">THESE ARE NOT THE PAGES YOU ARE LOOKING FOR!</h2>
        <div class="prompt">
            <p/><p>Really? 404? In this day and age? <strong>REALLY?!</strong></p>
            <br/><p>Boy, you must feel so ashamed.</p>
            <br/><p>Were you just making up urls or what? I mean, we've seen some pretend urls in our day,
                but COME ON! It's like you're not even trying.</p>

            <br/><p>In closing, <a href="/cas/login">go away</a>. </p>
            
        </div>
    </div>
</div>

    <div><script type="text/javascript" src="/cas/js/cas.js"></script>



</div>
</body>
</html>
